#include "BumpersOK.h"



using namespace BT;

BumpersOK::BumpersOK(std::string Name) : ConditionNode::ConditionNode(Name)
{
    Type = Condition;
    // Thread start
    Thread = boost::thread(&BumpersOK::Exec, this);




}

BumpersOK::~BumpersOK() {}

void BumpersOK::Exec()
{
	  // create the action client
	  // true causes the client to spin its own thread
      actionlib::SimpleActionClient<bt_actions::BTAction> ac("bumpersok", true);
      bool outcomeOK = false;

	  ac.waitForServer(); //will wait for infinite time until the server starts
          bt_actions::BTGoal goal;

    while(true)
    {
        // Waiting for a tick to come
        Semaphore.Wait();

        if(ReadState() == Exit)
        {
            // The behavior tree is going to be destroied
            return;
        }

        // Running state
        SetNodeState(Running);
        std::cout << Name << " returning " << Running << "!" << std::endl;
        node_result.status = 0;
        // Perform action...
        int i=0;
        ROS_INFO("I am running the request");
        ac.sendGoal(goal);
        do{
            node_result = *(ac.getResult());
        }while(ReadState() == Running && (node_result.status != 2 || node_result.status != 1  )); //if it is not halted and has not returned a status


        if(node_result.status == 1){
            outcomeOK = WriteState(Success);
            ROS_INFO("BumpersOK returns SUCCESS");


        }
        if(node_result.status == 2){
            outcomeOK = WriteState(Failure);
            ROS_INFO("BumpersOK returns FAILURE");


        }


        if(ReadState() == Exit)
        {
            // The behavior tree is going to be destroied
            return;
        }





            // trying to set the outcome state:
            if (!outcomeOK)
            {
                // meanwhile, my father halted me!
                std::cout << Name << " Halted!" << std::endl;
                		ROS_INFO("I am cancelling the request");
                  ac.cancelGoal();
                // Resetting the state
                WriteState(Idle);
                continue;
            }

        

        // Synchronization
        // (my father is telling me that it has read my new state)
        Semaphore.Wait();

        if(ReadState() == Exit)
        {
            // The behavior tree is going to be destroied
            return;
        }

        // Resetting the state
        WriteState(Idle);
    }
}

